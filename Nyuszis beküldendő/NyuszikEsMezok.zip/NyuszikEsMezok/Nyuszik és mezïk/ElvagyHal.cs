﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nyuszik_és_mezők
{
    public interface ElvagyHal
    {
        void Szule(int i, int j);
        void Hale(int i, int j); //Fish?
    }
}
